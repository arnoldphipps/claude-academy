-- Run this in Supabase SQL Editor
-- Adds columns for saving student drafts and best scores

ALTER TABLE progress ADD COLUMN IF NOT EXISTS last_answer TEXT;
ALTER TABLE progress ADD COLUMN IF NOT EXISTS best_score INTEGER DEFAULT 0;
